using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerUser : Player
{
    void Awake()
    {
        // for checking the player script from the beginning
        // if a player user script already exists (from the title scene), destroy this object.
    }

    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    // Player movement
    public void MovePlayer()
    {

    }

    // Attack the other player with abilities 1 to 9
    public void UseAbility()
    {

    }

    // Receive Damage, check if dead, update UI
    public void ReceiveDamage(int dmg)
    {

    }
}
